#pragma once
#include <parser/parser.h>

using std::vector, std::string, glm::vec2;

vector<vec2> get_constant_stack(const vector<TokenOperator>& stack);